# Joey’s Acoustic Corner – Kodi 21 compatible
import xbmcplugin, xbmcgui, xbmcaddon, sys, urllib.request, json

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])

EP_URL = "https://mellifluous-tanuki-51d911.netlify.app/episodes_MASTER_22.json"

def get_episodes():
    with urllib.request.urlopen(EP_URL) as r:
        return json.loads(r.read().decode("utf-8"))

def list_episodes():
    episodes = get_episodes()
    for ep in episodes:
        li = xbmcgui.ListItem(label=ep["title"])
        li.setInfo("video", {"title": ep["title"]})
        xbmcplugin.addDirectoryItem(handle, ep["tracks"][0]["url"], li, False)
    xbmcplugin.endOfDirectory(handle)

list_episodes()
